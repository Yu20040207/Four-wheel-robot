#include <SimpleFOC.h>
#define NSLP  7
#define NRST  8
#define DIR  3

// magnetic sensor instance - I2C
MagneticSensorI2C sensor = MagneticSensorI2C(AS5600_I2C);

// 电机参数设置：BLDCMotor(pp, R, KV, L)
// BLDCMotor motor = BLDCMotor(8, 2.5, 50, 0.0025);
BLDCMotor motor = BLDCMotor(8);
BLDCDriver3PWM driver = BLDCDriver3PWM(5, 6, 9, 4);

// angle set point variable
float target_angle = 0;
// instantiate the commander
Commander command = Commander(Serial);
void doTarget(char* cmd) { command.scalar(&target_angle, cmd); }

void setup() {

  // use monitoring with serial 
  Serial.begin(115200);
 
  pinMode(DIR, OUTPUT);  
  digitalWrite(NSLP, HIGH);
  digitalWrite(NRST, HIGH);
  digitalWrite(DIR, LOW);
 
  // enable more verbose output for debugging
  SimpleFOCDebug::enable(&Serial);

  // initialise magnetic sensor hardware
  sensor.init();
  // link the motor to the sensor
  motor.linkSensor(&sensor);

  // driver config
  // power supply voltage [V]
  driver.voltage_power_supply = 12;
  driver.init();
  // link the motor and the driver
  motor.linkDriver(&driver);

  // choose FOC modulation (optional)
  motor.foc_modulation = FOCModulationType::SpaceVectorPWM;

  // set motion control loop to be used
  motor.controller = MotionControlType::angle;

  // velocity PI controller parameters
  motor.PID_velocity.P = 0.2f;
  motor.PID_velocity.I = 10;
  motor.PID_velocity.D = 0;
  // maximal voltage to be set to the motor
  motor.voltage_limit = 11;

  // velocity low pass filtering time constant
  motor.LPF_velocity.Tf = 0.01f;

  // angle P controller
  motor.P_angle.P = 20;
  // maximal velocity of the position control
  motor.velocity_limit = 100;
  
  // comment out if not needed
  motor.useMonitoring(Serial);


  // initialize motor
  motor.init();

  // 跳过位置传感器对齐，提前设置校准值
  // motor.zero_electric_angle  = 1.85; // rad
  // motor.sensor_direction = Direction::CW; // CW or CCW

  // align sensor and start FOC
  motor.initFOC();

  // add target command T
  command.add('T', doTarget, "target angle");

  Serial.println(F("Motor ready."));
  Serial.println(F("Set the target angle using serial terminal:"));
  Serial.println("Motor ready.");
  _delay(1000);
}


void loop() {

  motor.loopFOC();

  motor.move();

  command.run();
}