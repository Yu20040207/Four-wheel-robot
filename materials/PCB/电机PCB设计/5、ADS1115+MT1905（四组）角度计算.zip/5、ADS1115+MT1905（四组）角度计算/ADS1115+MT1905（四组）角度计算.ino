#include<ADS1115_WE.h> 
#include<Wire.h>
#define I2C_ADDRESS 0x48

int16_t P0;
int16_t P1;
int16_t P2;
int16_t P3;
int32_t X;
int32_t Y;
float theta, angle_deg;

ADS1115_WE adc = ADS1115_WE(I2C_ADDRESS);

void setup() {
  Wire.begin();
  Serial.begin(115200);
  if(!adc.init()){
    Serial.println("ADS1115 not connected!");
  }

  adc.setVoltageRange_mV(ADS1115_RANGE_4096);   //设置 ADC 的电压范围以调整增益

  adc.setConvRate(ADS1115_475_SPS);             //设置转换速率, SPS（每秒采样数）

  adc.setMeasureMode(ADS1115_CONTINUOUS); 
}

void loop() {
 
  adc.setCompareChannels(ADS1115_COMP_0_GND);
  P0 = adc.getRawResult();
  
  adc.setCompareChannels(ADS1115_COMP_1_GND);
  P1 = adc.getRawResult();

  adc.setCompareChannels(ADS1115_COMP_2_GND);
  P2 = adc.getRawResult();

  adc.setCompareChannels(ADS1115_COMP_3_GND);
  P3 = adc.getRawResult();

  X = P0 - P1;
  Y = P2 - P3;

  theta = atan2(X, Y);              // 得到弧度，范围 -π 到 π

  angle_deg = theta * 180.0 / PI;   // 转换角度，范围 0 到 360

  if (angle_deg < 0)
      angle_deg += 360.0;

  Serial.print("d: ");
  // Serial.print(P0);
  // Serial.print(",");
  // Serial.print(P1);
  // Serial.print(",");
  // Serial.print(P2);
  // Serial.print(",");
  // Serial.print(P3);
  // Serial.print(",");
  Serial.print(angle_deg);
  Serial.print(",");
  Serial.println(theta);

}


