#include "BLDCMotor.h"
#include "./communication/SimpleFOCDebug.h"


// BLDCMotor( int pp , float R)
// - pp            - pole pair number
// - R             - motor phase resistance
// - KV            - motor kv rating (rmp/v)
// - L             - motor phase inductance
BLDCMotor::BLDCMotor(int pp, float _R, float _KV, float _inductance)
: FOCMotor()
{
  // 保存极对数
  pole_pairs = pp;
  // 保存相电阻数
  phase_resistance = _R;
  // 保存反电动势常数 KV = 1/KV
  // 1/sqrt(2) - 均方根值
  KV_rating = NOT_SET;
  if (_isset(_KV))
    KV_rating = _KV;
  // 保存相电感
  phase_inductance = _inductance;

  // 转矩控制类型默认为电压
  torque_controller = TorqueControlType::voltage;
}


/**
	链接控制电机的驱动器
*/
void BLDCMotor::linkDriver(BLDCDriver* _driver) {
  driver = _driver;
}

// 初始化硬件引脚
int BLDCMotor::init() {
  if (!driver || !driver->initialized) {
    motor_status = FOCMotorStatus::motor_init_failed;
    SIMPLEFOC_DEBUG("MOT: Init not possible, driver not initialized");
    return 0;
  }
  motor_status = FOCMotorStatus::motor_initializing;
  SIMPLEFOC_DEBUG("MOT: Init");

  // 对电压限制配置进行完整性检查
  if(voltage_limit > driver->voltage_limit) voltage_limit =  driver->voltage_limit;
  // 限制传感器对准电压
  if(voltage_sensor_align > voltage_limit) voltage_sensor_align = voltage_limit;

  // 更新控制器限值
  if(current_sense){
    // 电流控制环控制电压
    PID_current_q.limit = voltage_limit;
    PID_current_d.limit = voltage_limit;
  }
  if(_isset(phase_resistance) || torque_controller != TorqueControlType::voltage){
    // 速度控制环控制电流
    PID_velocity.limit = current_limit;
  }else{
    // 速度控制环控制电压
    PID_velocity.limit = voltage_limit;
  }
  P_angle.limit = velocity_limit;

  // 如果使用开环控制，请将 CW 设置为默认方向（如果尚未设置）
  // if ((controller==MotionControlType::angle_openloop
  //    ||controller==MotionControlType::velocity_openloop)
  //    && (sensor_direction == Direction::UNKNOWN)) {
  //     sensor_direction = Direction::CW;
  // }

  _delay(500);
  // 使能电机
  SIMPLEFOC_DEBUG("MOT: Enable driver.");
  enable();
  _delay(500);
  motor_status = FOCMotorStatus::motor_uncalibrated;
  return 1;
}


// 禁用电机驱动器
void BLDCMotor::disable()
{
  // 禁用电流检测
  if(current_sense) current_sense->disable();
  // 将PWM信号设置为零
  driver->setPwm(0, 0, 0);
  // 禁用驱动器
  driver->disable();
  // 更新电机状态
  enabled = 0;
}
// 启用电机驱动器
void BLDCMotor::enable()
{
  // 启用驱动器
  driver->enable();
  // 将PWM信号设置为零
  driver->setPwm(0, 0, 0);
  // 启用电流检测
  if(current_sense) current_sense->enable();
  // 重置PID
  PID_velocity.reset();
  P_angle.reset();
  PID_current_q.reset();
  PID_current_d.reset();
  // 更新电机状态
  enabled = 1;
}

/**
  FOC 函数
*/
// FOC 初始化函数
int  BLDCMotor::initFOC() {
  int exit_flag = 1;

  motor_status = FOCMotorStatus::motor_calibrating;

  // 必要时校准电机
  // 编码器校准必不可少！
  // 传感器和电机校准 - 可跳过
  // 通过设置motor.sensor_direction 和 motor.zero_electric_angle
  if(sensor){
    exit_flag *= alignSensor();
    // 添加了 shaft_angle 更新
    sensor->update();
    shaft_angle = shaftAngle();

    // 校准电流传感器 - 可跳过
    // 检查驱动器相位是否与电流检测相位相同
    // 并检查测量方向。
    if(exit_flag){
      if(current_sense){ 
        if (!current_sense->initialized) {
          motor_status = FOCMotorStatus::motor_calib_failed;
          SIMPLEFOC_DEBUG("MOT: Init FOC error, current sense not initialized");
          exit_flag = 0;
        }else{
          exit_flag *= alignCurrentSense();
        }
      }
      else { SIMPLEFOC_DEBUG("MOT: No current sense."); }
    }

  } 
  // else {
  //   SIMPLEFOC_DEBUG("MOT: No sensor.");
  //   if ((controller == MotionControlType::angle_openloop || controller == MotionControlType::velocity_openloop)){
  //     exit_flag = 1;    
  //     SIMPLEFOC_DEBUG("MOT: Openloop only!");
  //   }else{
  //     exit_flag = 0; // 无传感器，无 FOC
  //   }
  // }

  if(exit_flag){
    SIMPLEFOC_DEBUG("MOT: Ready.");
    motor_status = FOCMotorStatus::motor_ready;
  }else{
    SIMPLEFOC_DEBUG("MOT: Init FOC failed.");
    motor_status = FOCMotorStatus::motor_calib_failed;
    disable();
  }

  return exit_flag;
}

// 校准电机和电流检测相位
int BLDCMotor::alignCurrentSense() {
  int exit_flag = 1; // 成功

  SIMPLEFOC_DEBUG("MOT: Align current sense.");

  // 校准电流检测和驱动器
  exit_flag = current_sense->driverAlign(voltage_sensor_align, modulation_centered);
  if(!exit_flag){
    // 电流检测错误 - 相位未测量或连接不良
    SIMPLEFOC_DEBUG("MOT: Align error!");
    exit_flag = 0;
  }else{
    // 输出校准状态标志
    SIMPLEFOC_DEBUG("MOT: Success: ", exit_flag);
  }

  return exit_flag > 0;
}

// 编码器与电气零角对齐
int BLDCMotor::alignSensor() {
  int exit_flag = 1; //成功
  SIMPLEFOC_DEBUG("MOT: Align sensor.");

  // 检查传感器是否需要零点搜索
  if(sensor->needsSearch()) exit_flag = absoluteZeroSearch();
  // 如果未找到索引，则停止初始化
  if(!exit_flag) return exit_flag;

  // v2.3.3 修复了 AVR 开发板中 R_AVR_7_PCREL 的“符号”错误
  // TODO 找出原因
  float voltage_align = voltage_sensor_align;

  // 如果自然方向未知
  if(sensor_direction==Direction::UNKNOWN){

    // 找到自然方向
    // 向前移动一圈电气旋转
    for (int i = 0; i <=500; i++ ) {
      float angle = _3PI_2 + _2PI * i / 500.0f;
      setPhaseVoltage(voltage_align, 0,  angle);
	    sensor->update();
      _delay(2);
    }
    // 获取中间角度
    sensor->update();
    float mid_angle = sensor->getAngle();
    // 向后移动一圈电气旋转
    for (int i = 500; i >=0; i-- ) {
      float angle = _3PI_2 + _2PI * i / 500.0f ;
      setPhaseVoltage(voltage_align, 0,  angle);
	    sensor->update();
      _delay(2);
    }
    sensor->update();
    float end_angle = sensor->getAngle();
    // setPhaseVoltage(0, 0, 0);
    _delay(200);
    // 确定传感器移动的方向
    float moved =  fabs(mid_angle - end_angle);
    if (moved<MIN_ANGLE_DETECT_MOVEMENT) { // 检测移动的最小角度
      SIMPLEFOC_DEBUG("MOT: Failed to notice movement");
      return 0; // 校准失败
    } else if (mid_angle < end_angle) {
      SIMPLEFOC_DEBUG("MOT: sensor_direction==CCW");
      sensor_direction = Direction::CCW;
    } else{
      SIMPLEFOC_DEBUG("MOT: sensor_direction==CW");
      sensor_direction = Direction::CW;
    }
    // 检查极对数
    pp_check_result = !(fabs(moved*pole_pairs - _2PI) > 0.5f); // 0.5f 是任意数，可以更低或更高！
    if( pp_check_result==false ) {
      SIMPLEFOC_DEBUG("MOT: PP check: fail - estimated pp: ", _2PI/moved);
    } else {
      SIMPLEFOC_DEBUG("MOT: PP check: OK!");
    }

  } else { SIMPLEFOC_DEBUG("MOT: Skip dir calib."); }

  // 零电角未知
  if(!_isset(zero_electric_angle)){
    // 对齐电机和传感器的电相位
    // 设置角度 -90(270 = 3PI/2) 度
    setPhaseVoltage(voltage_align, 0,  _3PI_2);
    _delay(700);
    // 读取传感器
    sensor->update();
    // 获取当前零电角
    zero_electric_angle = 0;
    zero_electric_angle = electricalAngle();
    //zero_electric_angle =  _normalizeAngle(_electricalAngle(sensor_direction*sensor->getAngle(), pole_pairs));
    _delay(20);
    if(monitor_port){
      SIMPLEFOC_DEBUG("MOT: Zero elec. angle: ", zero_electric_angle);
    }
    // 停止所有操作
    setPhaseVoltage(0, 0, 0);
    _delay(200);
  } else { SIMPLEFOC_DEBUG("MOT: Skip offset calib."); }
  return exit_flag;
}

// 编码器校准绝对零度角
// - 到索引
int BLDCMotor::absoluteZeroSearch() {
  // 传感器精度：这没问题，因为搜索发生在零度角附近，此时浮点数的精度足够了。
  SIMPLEFOC_DEBUG("MOT: Index search...");
  // 以较小的速度搜索绝对零度
  float limit_vel = velocity_limit;
  float limit_volt = voltage_limit;
  velocity_limit = velocity_index_search;
  voltage_limit = voltage_sensor_align;
  shaft_angle = 0;
  while(sensor->needsSearch() && shaft_angle < _2PI){
    //angleOpenloop(1.5f*_2PI);
    // 对于某些传感器来说，调用此函数很重要，以免丢失计数
    // 搜索时不需要
    sensor->update();
  }
  // 禁用电机
  setPhaseVoltage(0, 0, 0);
  // 重新初始化限值
  velocity_limit = limit_vel;
  voltage_limit = limit_volt;
  // 检查是否找到零点
  if(monitor_port){
    if(sensor->needsSearch()) { SIMPLEFOC_DEBUG("MOT: Error: Not found!"); }
    else { SIMPLEFOC_DEBUG("MOT: Success!"); }
  }
  return !sensor->needsSearch();
}

// 迭代函数循环 FOC 算法，设置电机的 Uq
// 运行速度越快越好
void BLDCMotor::loopFOC() {
  // 更新传感器 - 即使在开环模式下也执行此操作，因为用户可能在不同模式之间切换
  //             ，否则我们可能会丢失完整的旋转轨迹。
  if (sensor) sensor->update();

  // 如果是开环模式，则不执行任何操作
  // if( controller==MotionControlType::angle_openloop || controller==MotionControlType::velocity_openloop ) return;
  
  // 如果禁用，则不执行任何操作
  if(!enabled) return;

  // 需要先调用 update()
  // 此函数不会出现数值问题，因为它使用了 Sensor::getMechanicalAngle() 
  // 其范围在 0-2PI 之间
  electrical_angle = electricalAngle();
  switch (torque_controller) {
    case TorqueControlType::voltage:
      // 无需执行任何操作
      break;
    // case TorqueControlType::dc_current:
    //   if(!current_sense) return;
    //   // read overall current magnitude
    //   current.q = current_sense->getDCCurrent(electrical_angle);
    //   // filter the value values
    //   current.q = LPF_current_q(current.q);
    //   // calculate the phase voltage
    //   voltage.q = PID_current_q(current_sp - current.q);
    //   // d voltage  - lag compensation
    //   if(_isset(phase_inductance)) voltage.d = _constrain( -current_sp*shaft_velocity*pole_pairs*phase_inductance, -voltage_limit, voltage_limit);
    //   else voltage.d = 0;
    //   break;
    case TorqueControlType::foc_current:
      if(!current_sense) return;
      // 读取 dq 电流
      current = current_sense->getFOCCurrents(electrical_angle);
      // 滤波值
      current.q = LPF_current_q(current.q);
      current.d = LPF_current_d(current.d);
      // 计算相电压
      voltage.q = PID_current_q(current_sp - current.q);
      voltage.d = PID_current_d(-current.d);
      // d 电压 - 滞后补偿 - TODO 验证
      if(_isset(phase_inductance)) voltage.d = _constrain( voltage.d - current_sp*shaft_velocity*pole_pairs*phase_inductance, -voltage_limit, voltage_limit);
      break;
    default:
      // 未选择转矩控制
      SIMPLEFOC_DEBUG("MOT: no torque control selected!");
      break;
  }

  // 设置相电压 - FOC 核心函数 :)
  setPhaseVoltage(voltage.q, voltage.d, electrical_angle);
}

// 迭代函数，运行 FOC 算法的外层循环
// 此函数的行为由 motor.controller 变量决定
// 它运行角度、速度或扭矩循环
// - 需要迭代调用，它是异步函数
// - 如果未设置目标，则使用 motor.target 值
void BLDCMotor::move(float new_target) {

  // 设置内部目标变量
  if(_isset(new_target)) target = new_target;
  
  // 下采样（可选）
  if(motion_cnt++ < motion_downsample) return;
  motion_cnt = 0;

  // 轴角度/速度需要先调用 update()
  // 获取轴角度
  // TODO 传感器精度: shaft_angle 实际上以浮点数存储完整的位置，包括完整的旋转。
  //                 因此，当角度变大时，它并不精确。
  //                 此外，LPF 处理角度的方式存在精度问题，而角度 LPF 在切换到双分量表示时也存在问题。
  // if( controller!=MotionControlType::angle_openloop && controller!=MotionControlType::velocity_openloop ) 
    shaft_angle = shaftAngle(); // 即使电机已禁用，也要读取值以保持监控更新，但不在开环模式下
  // // 获取角速度 TODO 速度读取可能也不应该在开环模式下进行？
  shaft_velocity = shaftVelocity(); // 即使电机已禁用，也要读取值以保持监控更新

  // 如果禁用，则不执行任何操作
  if(!enabled) return;
  
  // 如果 KV_rating 可用，则计算反电动势电压 U_bemf = vel*(1/KV)
  if (_isset(KV_rating)) voltage_bemf = shaft_velocity/(KV_rating*_SQRT3)/_RPM_TO_RADS;
  // 如果相电阻可用且 current_sense 不可用，则估算电机电流
  if(!current_sense && _isset(phase_resistance)) current.q = (voltage.q - voltage_bemf)/phase_resistance;

  // 升级基于电流的电压限制
  switch (controller) {
    case MotionControlType::torque:
      if(torque_controller == TorqueControlType::voltage){ // 如果是电压扭矩控制
        if(!_isset(phase_resistance))  voltage.q = target;
        else  voltage.q =  target*phase_resistance + voltage_bemf;
        voltage.q = _constrain(voltage.q, -voltage_limit, voltage_limit);
        // 设置d分量（如果已知电感，则进行滞后补偿）
        if(!_isset(phase_inductance)) voltage.d = 0;
        else voltage.d = _constrain( -target*shaft_velocity*pole_pairs*phase_inductance, -voltage_limit, voltage_limit);
      }else{
        current_sp = target; // 如果是电流/foc_current扭矩控制
      }
      break;
    case MotionControlType::angle:
      // TODO 传感器精度: 此计算在数值上不够精确。当角度较大时，目标值无法表达精确的位置。
      //                 这导致无法在高位置值下控制微小的变化。
      //                 为了解决这个问题，必须以精确的数值方式计算角度增量。
      // 角度设定点
      shaft_angle_sp = target;
      // 计算速度设定点
      shaft_velocity_sp = feed_forward_velocity + P_angle( shaft_angle_sp - shaft_angle );
      shaft_velocity_sp = _constrain(shaft_velocity_sp,-velocity_limit, velocity_limit);
      // 计算扭矩指令 - 传感器精度：此计算正常，但基于上次计算的错误值
      current_sp = PID_velocity(shaft_velocity_sp - shaft_velocity); // 如果是电压转矩控制
      // 如果是通过电压控制转矩
      if(torque_controller == TorqueControlType::voltage){
        // 如果未提供相电阻，则使用电压
        if(!_isset(phase_resistance))  voltage.q = current_sp;
        else  voltage.q =  _constrain( current_sp*phase_resistance + voltage_bemf , -voltage_limit, voltage_limit);
        // 设置d分量（如果已知电感，则进行滞后补偿）
        if(!_isset(phase_inductance)) voltage.d = 0;
        else voltage.d = _constrain( -current_sp*shaft_velocity*pole_pairs*phase_inductance, -voltage_limit, voltage_limit);
      }
      break;
    case MotionControlType::velocity:
      // 速度设定点 - 传感器精度：此计算在数值上非常精确。
      shaft_velocity_sp = target;
      // 计算扭矩指令
      current_sp = PID_velocity(shaft_velocity_sp - shaft_velocity); // 如果采用电流/foc_current 扭矩控
      // 如果扭矩通过电压控制
      if(torque_controller == TorqueControlType::voltage){
        // 如果未提供相电阻，则使用电压
        if(!_isset(phase_resistance))  voltage.q = current_sp;
        else  voltage.q = _constrain( current_sp*phase_resistance + voltage_bemf , -voltage_limit, voltage_limit);
        // 设置 d 分量（如果已知电感，则进行滞后补偿）
        if(!_isset(phase_inductance)) voltage.d = 0;
        else voltage.d = _constrain( -current_sp*shaft_velocity*pole_pairs*phase_inductance, -voltage_limit, voltage_limit);
      }
      break;
  }
}


// 使用 FOC 将 Uq 和 Ud 设置为电机最佳角度的方法
// 实现空间矢量 PWM 和正弦 PWM 算法的函数
//
// 使用正弦近似值的函数
// 常规 sin + cos 约 300us（不占用内存）
// 近似  _sin + _cos 约 110us  （400 字节，约占内存的 20%）
void BLDCMotor::setPhaseVoltage(float Uq, float Ud, float angle_el) {

  float center;
  int sector;
  float _ca,_sa;

  switch (foc_modulation)
  {

    case FOCModulationType::SinePWM :
    case FOCModulationType::SpaceVectorPWM :
      // 正弦 PWM 调制
      // Park + Clarke 逆变换
      _sincos(angle_el, &_sa, &_ca);

      // 逆 Park 变换
      Ualpha =  _ca * Ud - _sa * Uq;  // -sin(angle) * Uq;
      Ubeta =  _sa * Ud + _ca * Uq;    //  cos(angle) * Uq;

      // Clarke 变换
      Ua = Ualpha;
      Ub = -0.5f * Ualpha + _SQRT3_2 * Ubeta;
      Uc = -0.5f * Ualpha - _SQRT3_2 * Ubeta;

      center = driver->voltage_limit/2;
      if (foc_modulation == FOCModulationType::SpaceVectorPWM){
        // 此处讨论：: https://community.simplefoc.com/t/embedded-world-2023-stm32-cordic-co-processor/3107/165?u=candas1
        // 这里有更多信息： https://microchipdeveloper.com/mct5001:which-zsm-is-best
        // 中点钳位
        float Umin = min(Ua, min(Ub, Uc));
        float Umax = max(Ua, max(Ub, Uc));
        center -= (Umax+Umin) / 2;
      } 

      if (!modulation_centered) {
        float Umin = min(Ua, min(Ub, Uc));
        Ua -= Umin;
        Ub -= Umin;
        Uc -= Umin;
      }else{
        Ua += center;
        Ub += center;
        Uc += center;
      }

      break;

  }

  // 设置驱动器中的电压
  driver->setPwm(Ua, Ub, Uc);
}

