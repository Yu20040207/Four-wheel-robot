#include "CurrentSense.h"
#include "../../communication/SimpleFOCDebug.h"


// 与 foc 算法一起使用的函数
//   根据相电流计算 DQ 电流
//   - 计算相电流的 Park 和 Clarke 变换的函数 
//   - 内部使用 getPhaseCurrents 和 getABCurrents
DQCurrent_s CurrentSense::getFOCCurrents(float angle_el){
    // 读取当前相电流
    PhaseCurrent_s current = getPhaseCurrents();

    // 计算克拉克变换
    ABCurrent_s ABcurrent = getABCurrents(current);
    
    // 计算帕克变换
    DQCurrent_s return_current = getDQCurrents(ABcurrent,angle_el);

    return return_current;
}

// 与 foc 算法一起使用的函数
//   根据相电流计算 Alpha Beta 电流
//   - 计算相电流的 Clarke 变换的函数
ABCurrent_s CurrentSense::getABCurrents(PhaseCurrent_s current){

    // 检查驱动器是否为 StepperDriver 实例
    // if so there is no need to Clarke transform
    //if (driver_type == DriverType::Stepper){
    //    ABCurrent_s return_ABcurrent;
    //    return_ABcurrent.alpha = current.a;
    //    return_ABcurrent.beta = current.b;
    //    return return_ABcurrent;
    //}

    // 否则为 BLDC 电机
    // 计算 Clarke 变换
    float i_alpha, i_beta;
    if(!current.c){
        // 如果只有两个测量电流
        i_alpha = current.a;  
        i_beta = _1_SQRT3 * current.a + _2_SQRT3 * current.b;
    }else if(!current.a){
        // 如果只有两个测量电流
        float a = -current.c - current.b;
        i_alpha = a;  
        i_beta = _1_SQRT3 * a + _2_SQRT3 * current.b;
    }else if(!current.b){
        // 如果只有两个测量电流
        float b = -current.a - current.c;
        i_alpha = current.a;  
        i_beta = _1_SQRT3 * current.a + _2_SQRT3 * b;
    } else {
        // 使用恒等式 a + b + c = 0 进行信号滤波。假设测量误差呈正态分布。
        float mid = (1.f/3) * (current.a + current.b + current.c);
        float a = current.a - mid;
        float b = current.b - mid;
        i_alpha = a;
        i_beta = _1_SQRT3 * a + _2_SQRT3 * b;
    }

    ABCurrent_s return_ABcurrent;
    return_ABcurrent.alpha = i_alpha;
    return_ABcurrent.beta = i_beta;
    return return_ABcurrent;
}

// 与 foc 算法一起使用的函数
//   根据 Alpha Beta 电流和电角度计算 D 和 Q 电流
//   - 计算相电流的 Clarke 变换的函数
DQCurrent_s CurrentSense::getDQCurrents(ABCurrent_s current, float angle_el){
 // 计算 Park 变换
    float ct;
    float st;
    _sincos(angle_el, &st, &ct);
    DQCurrent_s return_current;
    return_current.d = current.alpha * ct + current.beta * st;
    return_current.q = current.beta * ct - current.alpha * st;
    return return_current;
}

/**
	驱动器链接到电流感测
*/
void CurrentSense::linkDriver(FOCDriver* _driver) {
    driver = _driver;
    // 保存驱动器类型以便于访问
    driver_type = driver->type();
}


void CurrentSense::enable(){
    // 这里没有执行任何操作，但您可以重写此函数
};

void CurrentSense::disable(){
    // 这里没有执行任何操作，但您可以重写此函数
};


// 函数用于将电流感测与电机驱动器对齐
// 如果所有引脚连接良好，则这些操作都没有必要！——可以避免
// 返回标志
// 0 - 失败
// 1 - 成功，没有任何变化
// 2 - 成功，但引脚已重新配置
// 3 - 成功，但增益反转
// 4 - 成功，但引脚已重新配置，增益反转
// 重要提示：此函数可在子类中重写
int CurrentSense::driverAlign(float voltage, bool modulation_centered){
        
    int exit_flag = 1;
    if(skip_align) return exit_flag;

    if (!initialized) return 0;

    // 检查步进电机还是无刷直流电机
    //if(driver_type == DriverType::Stepper)
    //    return alignStepperDriver(voltage, (StepperDriver*)driver, modulation_centered);
    //else
        return alignBLDCDriver(voltage, (BLDCDriver*)driver, modulation_centered);
}



// 用于读取和平均相电流的辅助函数
PhaseCurrent_s CurrentSense::readAverageCurrents(int N) {
    PhaseCurrent_s c = getPhaseCurrents();
    for (int i = 0; i < N; i++) {
        PhaseCurrent_s c1 = getPhaseCurrents();
        c.a = c.a * 0.6f + 0.4f * c1.a;
        c.b = c.b * 0.6f + 0.4f * c1.b;
        c.c = c.c * 0.6f + 0.4f * c1.c;
        _delay(3);
    }
    return c;
};



// 函数用于将电流感测与电机驱动器对齐
// 如果所有引脚连接良好，则这些操作都没有必要！- 可以避免
// 返回标志
// 0 - 失败
// 1 - 成功，没有任何变化
// 2 - 成功，但引脚已重新配置
// 3 - 成功，但增益已反转
// 4 - 成功，但引脚已重新配置，增益已反转
int CurrentSense::alignBLDCDriver(float voltage, BLDCDriver* bldc_driver, bool modulation_centered){
        
    bool phases_switched = 0;
    bool phases_inverted = 0;
    
    float zero = 0;
    if(modulation_centered) zero = driver->voltage_limit/2.0;

    // 将 A 相设置为有效，并将 B 相和 C 相设置为关闭
    // 300 毫秒的斜坡上升
    for(int i=0; i < 100; i++){
        bldc_driver->setPwm(voltage/100.0*((float)i)+zero , zero, zero);
        _delay(3);
    }
    _delay(500);
    PhaseCurrent_s c_a = readAverageCurrents();
    bldc_driver->setPwm(zero, zero, zero);
    // 检查电流是否过低（低于 100mA）
    // TODO 根据 ADC 分辨率计算 100mA 阈值
    // 如果是，则抛出错误并返回 0
    // 电流传感器未连接，或电流
    // 过低，无法进行校准（应提高
    if((fabs(c_a.a) < 0.1f) && (fabs(c_a.b) < 0.1f) && (fabs(c_a.c) < 0.1f)){
            SIMPLEFOC_DEBUG("CS: Err too low current, rise voltage!");
            return 0; // 测量电流过低
    }

    
    // 现在我们需要确定
    // 1) 哪个引脚对应 BLDC 驱动器的哪个相
    // 2) 测量的电流极性是否正确
    //
    // > 当我们在驱动器的 A 相施加电压时，我们期望测量的是 A 相的电流 I
    // B 相的电流为 -I/2，C 相的电流为 I/2

    // 找到 c_a 中的最大幅值
    // 并确保它比其他两个幅值高出大约 2 倍（至少 1.5 倍）
    float ca[3] = {fabs(c_a.a), fabs(c_a.b), fabs(c_a.c)};
    uint8_t max_i = -1;     // 最大索引
    float max_c = 0;        // 最大电流
    float max_c_ratio = 0;  // 最大电流比
    for(int i = 0; i < 3; i++){
        if(!ca[i]) continue; // 未测量电流
        if(ca[i] > max_c){
            max_c = ca[i];
            max_i = i;
            for(int j = 0; j < 3; j++){
                if(i == j) continue;
                if(!ca[j]) continue; // 未测量电流
                float ratio = max_c / ca[j];
                if(ratio > max_c_ratio) max_c_ratio = ratio;
            }
        }
    }

    // 检查电流幅值比
    // 1) 如果有一个电流大约是其他两个电流的2倍
    //    此电流为A相电流
    // 2) 如果最大电流未至少是其他两个电流的1.5倍
    //    我们有两种情况：
    //    - 要么我们只测量两个电流，而第三个电流没有测量 - 那么A相就没有测量
    //    - 或者电流传感器连接不正确

    if(max_c_ratio >=1.5f){
        switch (max_i){
            case 1: // B 相为最大电流
                SIMPLEFOC_DEBUG("CS: Switch A-B");
                // switch phase A and B
                _swap(pinA, pinB);
                _swap(offset_ia, offset_ib);
                _swap(gain_a, gain_b);
                _swap(c_a.b, c_a.b);
                phases_switched = true; // 表示引脚已切换
                break;
            case 2: // C 相为最大电流
                SIMPLEFOC_DEBUG("CS: Switch A-C");
                // switch phase A and C
                _swap(pinA, pinC);
                _swap(offset_ia, offset_ic);
                _swap(gain_a, gain_c);
                _swap(c_a.a, c_a.c);
                phases_switched = true;// 表示引脚已切换
                break;
        }
        // 检查电流是否为负，如果是，则反转增益
        if( _sign(c_a.a) < 0 ){
            SIMPLEFOC_DEBUG("CS: Inv A");
            gain_a *= -1;
            phases_inverted = true; // 表示引脚已反转
        }
    }else if(_isset(pinA) && _isset(pinB) && _isset(pinC)){
            // 如果测量所有三个电流，且没有一个电流明显高于此值
            // 电流检测存在问题
        SIMPLEFOC_DEBUG("CS: Err A - all currents same magnitude!");
        return 0;
    }else{  // A相未测量，因此将_NC置于A相
        if(_isset(pinA) && !_isset(pinB)){
            SIMPLEFOC_DEBUG("CS: Switch A-(B)NC");
            _swap(pinA, pinB);
            _swap(offset_ia, offset_ib);
            _swap(gain_a, gain_b);
            _swap(c_a.b, c_a.b);
            phases_switched = true; // 表示引脚已切换
        }else if(_isset(pinA) && !_isset(pinC)){
            SIMPLEFOC_DEBUG("CS: Switch A-(C)NC");
            _swap(pinA, pinC);
            _swap(offset_ia, offset_ic);
            _swap(gain_a, gain_c);
            _swap(c_a.b, c_a.c);
            phases_switched = true; // 表示引脚已切换
        }
    }
    // 此时，A 相的电流感应可以是：
    // - 与驱动器 A 相对齐
    // - 或者未测量 A 相，且 _NC 连接到 A 相
    //
    // 无论哪种情况，A 相都已完成，现在我们必须检查 B 相和 C 相

    
    // 将 B 相设置为有效，并将 A 相和 C 相设置为关闭
    // 300 ms 的斜坡上升
    for(int i=0; i < 100; i++){
        bldc_driver->setPwm(zero, voltage/100.0*((float)i)+zero, zero);
        _delay(3);
    }
    _delay(500);
    PhaseCurrent_s c_b = readAverageCurrents();
    bldc_driver->setPwm(zero, zero, zero);

    // 检查 B 相
    // 找到 c_b 中的最大幅值
    // 并确保它比其他两个相高出大约 2 倍（至少 1.5 倍）
    float cb[3] = {fabs(c_b.a), fabs(c_b.b), fabs(c_b.c)};
    max_i = -1;     // 最大索引
    max_c = 0;      // 最大电流
    max_c_ratio = 0; // 最大电流比
    for(int i = 0; i < 3; i++){
        if(!cb[i]) continue; // 未测量电流
        if(cb[i] > max_c){
            max_c = cb[i];
            max_i = i;
            for(int j = 0; j < 3; j++){
                if(i == j) continue;
                if(!cb[j]) continue; // 未测量电流
                float ratio = max_c / cb[j];
                if(ratio > max_c_ratio) max_c_ratio = ratio;
            }
        }
    }
    if(max_c_ratio >= 1.5f){
        switch (max_i){
            case 0: // A 相为最大电流
                    // 由于 A 相已对齐，因此这是一个错误
                SIMPLEFOC_DEBUG("CS: Err align B");
                return 0;
            case 2: // C 相为最大电流
                SIMPLEFOC_DEBUG("CS: Switch B-C");
                _swap(pinB, pinC);
                _swap(offset_ib, offset_ic);
                _swap(gain_b, gain_c);
                _swap(c_b.b, c_b.c);
                phases_switched = true; // 表示引脚已切换
                break;
        }
        // 检查电流是否为负，如果是，则反转增益
        if( _sign(c_b.b) < 0 ){
            SIMPLEFOC_DEBUG("CS: Inv B");
            gain_b *= -1;
            phases_inverted = true; // 表示引脚已反转
        }
    }else if(_isset(pinB) && _isset(pinC)){
        // 如果测量所有三个电流，且没有一个电流明显高于此值
        // 电流感应存在问题
        SIMPLEFOC_DEBUG("CS: Err B - all currents same magnitude!");
        return 0;
    }else{ // 未测量 B 相，因此将 _NC 置于 B 相
        if(_isset(pinB) && !_isset(pinC)){
            SIMPLEFOC_DEBUG("CS: Switch B-(C)NC");
            _swap(pinB, pinC);
            _swap(offset_ib, offset_ic);
            _swap(gain_b, gain_c);
            _swap(c_b.b, c_b.c);
            phases_switched = true; // 表示引脚已切换
        }
    }
    // 此时，A 相和 B 相的电流感测可以是：
    // - 与驱动器的 A 相和 B 相对齐
    // - 或者 A 相和 B 相未测量，且 _NC 连接到 A 相和 B 相
    //
    // 无论哪种情况，A 相和 B 相都已完成，现在我们必须检查 C 相
    // 如果测量了 C 相（而非 _NC），则 C 相也已对齐
    // 我们必须检查电流是否为负，如果是，则反转增益
    if(_isset(pinC)){
        if( _sign(c_b.c) > 0 ){ // 预期电流为 -I/2（如果 A 相和 B 相已对齐，且 C 相极性正确）
            SIMPLEFOC_DEBUG("CS: Inv C");
            gain_c *= -1;
            phases_inverted = true; // 表示引脚已反转
        }
    }

    // 构造返回标志
    // 如果相位已切换，返回 2
    // 如果增益已反转，返回 3
    // 如果两者均反转，返回 4
    uint8_t exit_flag = 1;
    if(phases_switched) exit_flag += 1;
    if(phases_inverted) exit_flag += 2;
    return exit_flag;
}


