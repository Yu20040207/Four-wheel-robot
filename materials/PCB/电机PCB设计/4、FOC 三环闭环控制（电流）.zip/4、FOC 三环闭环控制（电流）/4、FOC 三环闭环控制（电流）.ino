/*******************************************
注意：需依次从电流环、速度环、位置环重新调参
*******************************************/

#include <SimpleFOC.h>
#define NSLP  7
#define NRST  8
#define DIR  3

// 磁编码器实例
MagneticSensorI2C sensor = MagneticSensorI2C(AS5600_I2C);

// 电机参数设置：BLDCMotor(pp, R, KV, L)
BLDCMotor motor = BLDCMotor(8, 2.5, 50, 0.0025);
BLDCDriver3PWM driver = BLDCDriver3PWM(5, 6, 9, 4);

// 电流检测模块 - 以双分流器为例
// 0.01 = 分流电阻，50 = 放大倍数，A0/A1 = ADC 输入 
InlineCurrentSense current_sense = InlineCurrentSense(0.01, 100, A0, A1, _NC);

// velocity set point variable
float target_angle = 0;
// instantiate the commander
Commander command = Commander(Serial);
void doTarget(char* cmd) { command.scalar(&target_angle, cmd); }

void setup() {

  // 使用串口监控
  Serial.begin(115200);
 
  pinMode(DIR, OUTPUT);  
  digitalWrite(NSLP, HIGH);
  digitalWrite(NRST, HIGH);
  digitalWrite(DIR, LOW);
 
  // 启用更详细的调试输出
  SimpleFOCDebug::enable(&Serial);

  // 初始化磁编码器硬件
  sensor.init();
  // 将电机连接到传感器
  motor.linkSensor(&sensor);

  // 驱动器配置
  // 电源电压 [V]
  driver.voltage_power_supply = 12;
  driver.init();
  // 连接电机和驱动器
  motor.linkDriver(&driver);

  // aligning voltage 
  motor.voltage_sensor_align = 5;

  // 初始化电流检测
  current_sense.init();
  // 将驱动器与电流检测连接
  current_sense.linkDriver(&driver);

  // set motion control loop to be used
  motor.controller = MotionControlType::angle;
  motor.torque_controller = TorqueControlType::foc_current;
  motor.foc_modulation = FOCModulationType::SpaceVectorPWM;

  // 电流环 PID 参数
  motor.PID_current_q.P = 2;      //8
  motor.PID_current_q.I = 100;    //300
  motor.PID_current_q.D = 0;
  motor.LPF_current_q.Tf = 0.01;  // 低通滤波器时间常数

  // 速度环 PID 参数
  motor.PID_velocity.P = 0.08;   //0.08
  motor.PID_velocity.I = 0.5;     //0.5
  motor.PID_velocity.D = 0;
  // default voltage_power_supply
  motor.voltage_limit = 2;
  // jerk control using voltage voltage ramp
  motor.PID_velocity.output_ramp = 1000;
  motor.LPF_velocity.Tf = 0.01f;  // 低通滤波器时间常数

  // 位置环 PID 参数
  motor.P_angle.P = 20;
  // 位置控制允许的最大旋转速度
  motor.velocity_limit = 100;

  // 监视器
  motor.useMonitoring(Serial);

  // 初始化电机
  motor.init();

  // 连接电机和电流检测
  motor.linkCurrentSense(&current_sense);

  // 跳过位置传感器对齐，提前设置校准值
  // motor.zero_electric_angle  = 1.87; // rad
  // motor.sensor_direction = Direction::CW; // CW or CCW
  //跳过电流检测对齐
  // current_sense.skip_align  = true; // 默认为false

  // 校准传感器并启动 FOC
  motor.initFOC();

  // add target command T
  command.add('T', doTarget, "target angle");

  Serial.println(F("Motor ready."));
  Serial.println(F("Set the target angle using serial terminal:"));
  _delay(1000);
}

void loop() {

  motor.loopFOC();

  motor.move(target_angle);

  command.run();
}