// 通信输入
void UpdateComand(float *target) 
{
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    float newk = input.toFloat(); 
    if (newk != 0.0 || input == "0") {
      *target = newk;
    }
  }
}

// 获取多圈角度值
float getMultiTurnAngle(float current_angle) {
  float delta = current_angle - angle_prev;

  if (abs(delta) > 0.8f * _2PI) {
    if (delta > 0) {
      full_rotations -= 1;
    } else {
      full_rotations += 1;
    }
  }

  angle_prev = current_angle;

  return full_rotations * _2PI + angle_prev;
}
