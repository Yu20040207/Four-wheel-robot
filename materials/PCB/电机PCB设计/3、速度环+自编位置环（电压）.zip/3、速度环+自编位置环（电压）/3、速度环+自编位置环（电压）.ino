#include <SimpleFOC.h>
#define NSLP  7
#define NRST  8
#define DIR  3

// 多圈角度追踪器变量
float angle_prev = 0.0f;           // 上一次角度
int32_t full_rotations = 0;        // 圈数计数器
float raw_angle = 0;       // 单圈角度
float multi_turn_angle = 0;  // 多圈角度

// magnetic sensor instance - I2C
MagneticSensorI2C MotorSensor = MagneticSensorI2C(AS5600_I2C);
MagneticSensorI2C PositionSensor = MagneticSensorI2C(MT6708_I2C);

// 电机参数设置：BLDCMotor(pp, R, KV, L)
BLDCMotor motor = BLDCMotor(8);
BLDCDriver3PWM driver = BLDCDriver3PWM(5, 6, 9, 4);

// 手动实现位置环控制
PIDController positionPID = PIDController(50.0, 0.2, 0.0, 1000, 100);  // 位置环 PID

// 速度和位置目标值
float target_velocity = 0;
float target_position = 0;  // 目标位置 (弧度)

// 位置环参数
float current_position = 0;
float position_error = 0;
float velocity_command = 0;

void setup() {

  // use monitoring with serial 
  Serial.begin(115200);

  pinMode(DIR, OUTPUT);  
  digitalWrite(NSLP, HIGH);
  digitalWrite(NRST, HIGH);
  digitalWrite(DIR, LOW);

  // enable more verbose output for debugging
  SimpleFOCDebug::enable(&Serial);

  // 初始化并链接电机用编码器
  MotorSensor.init();
  motor.linkSensor(&MotorSensor);
  // 初始化位置用编码器
  PositionSensor.init();  

  // driver config
  // power supply voltage [V]
  driver.voltage_power_supply = 12;
  driver.init();
  // link the motor and the driver
  motor.linkDriver(&driver);

  // set motion control loop to be used
  motor.controller = MotionControlType::velocity;
  // motor.torque_controller = TorqueControlType::voltage;
  motor.foc_modulation = FOCModulationType::SpaceVectorPWM;

  // velocity PI controller parameters
  motor.PID_velocity.P = 0.2f;
  motor.PID_velocity.I = 11;
  motor.PID_velocity.D = 0;
  // default voltage_power_supply
  motor.voltage_limit = 11;
  // jerk control using voltage voltage ramp
  motor.PID_velocity.output_ramp = 1000;
  // velocity low pass filtering
  motor.LPF_velocity.Tf = 0.01f;

  // comment out if not needed
  motor.useMonitoring(Serial);

  // initialize motor
  motor.init();

  // 跳过位置传感器对齐，提前设置校准值
  motor.zero_electric_angle  = 1.87; // rad
  motor.sensor_direction = Direction::CW; // CW or CCW

  // align sensor and start FOC
  motor.initFOC();


  Serial.println(F("Motor ready."));
  _delay(1000);
}

void loop() {

  UpdateComand(&target_position);

  motor.loopFOC();

  raw_angle = PositionSensor.getSensorAngle();       // 单圈角度
  multi_turn_angle = getMultiTurnAngle(raw_angle) - 0.75;  // 多圈角度(误差弧度：0.75)

  // 获取负载侧的“位置传感器”角度
  position_error = target_position - multi_turn_angle;
  // 位置环 PID 计算，生成目标速度
  velocity_command = positionPID(position_error);  

  motor.target = velocity_command;
  
  motor.move();

  Serial.print("d: ");  
  // Serial.print(target_velocity);  
  // Serial.print(", ");  
  Serial.println(multi_turn_angle);  

}
